# -*- coding: utf-8 -*-
import logging
from telegram import Update
from telegram.ext import ContextTypes

from services.auth_manager import auth_manager
from database import user_repository, group_repository
from utils.decorators import require_admin
from database import group_repository

logger = logging.getLogger(__name__)
user_repo = user_repository

# ---------------- Базовая админка ----------------

@require_admin
async def admin_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Справка по административным командам"""
    help_text = (
        "👨‍💼 <b>Административные команды Shift Tracker Bot</b>\n\n"
        "📋 <b>Пользователи:</b>\n"
        "/admin_pending — ожидают одобрения\n"
        "/admin_approve &lt;user_id&gt; [group_key] — одобрить (+опц. группа)\n"
        "/admin_users — все пользователи\n"
        "/admin_removeuser &lt;user_id&gt; — удалить пользователя\n"
        "/admin_update_all_users — обновить профили\n\n"
        "👷 <b>Группы смен:</b>\n"
        "/admin_groups — список групп\n"
        "/admin_group_create &lt;key&gt; &lt;offset_days&gt; &lt;name...&gt;\n"
        "/admin_group_rename &lt;key&gt; &lt;new_name...&gt;\n"
        "/admin_group_set_offset &lt;key&gt; &lt;offset_days&gt;\n"
        "/admin_group_set_epoch &lt;key&gt; &lt;DD.MM.YYYY|none&gt;\n"
        "/admin_group_set_tz &lt;key&gt; &lt;hours&gt; — смещение от Москвы (напр. +7)\n"
        "/admin_group_set_tz_name &lt;key&gt; &lt;IANA_TZ|none&gt; — абсолютный пояс\n"
        "/admin_group_delete &lt;key&gt;\n"
        "/admin_set_group &lt;user_id&gt; &lt;group_key&gt; — назначить группу\n"
        "/admin_unset_group &lt;user_id&gt; — снять группу\n"
        "/admin_list_group &lt;group_key&gt; — пользователи группы\n\n"
        "🗓 <b>Глобальные графики:</b>\n"
        "/admin_schedules, /admin_schedule_create, /admin_schedule_edit, /admin_schedule_delete\n"
        "⚠️ Все действия логируются."
    )
    await update.message.reply_text(help_text, parse_mode='HTML')


@require_admin
async def update_all_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обновление данных всех пользователей из Telegram профилей"""
    await update.message.reply_text("🔄 Начинаю обновление данных пользователей...")
    users = user_repo.get_all_users()
    updated_count, failed_count = 0, 0

    for user in users:
        uid = user["user_id"]
        try:
            chat = await context.bot.get_chat(uid)
            user_repo.create_user(uid, chat.username, chat.first_name, chat.last_name)
            updated_count += 1
            logger.info(f"Пользователь {uid} обновлён: @{chat.username}")
        except Exception as e:
            failed_count += 1
            logger.error(f"Ошибка при обновлении {uid}: {e}")

    await update.message.reply_text(
        f"✅ Обновление завершено.\nОбновлено: {updated_count}\nОшибок: {failed_count}"
    )


@require_admin
async def admin_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Список пользователей: ожидающие / зарегистрированные (компактно)"""
    # 1) Получаем данные из уже существующих переменных в хэндлере
    try:
        data = rows  # часто так называется
    except NameError:
        try:
            data = users
        except NameError:
            try:
                data = user_list
            except NameError:
                data = None

    # 2) Если локальных данных нет — пробуем репозиторий (если он есть)
    if data is None:
        try:
            from database import user_repository as user_repo  # если модуль есть в проекте
            data = user_repo.list_users()
        except Exception:
            data = []

    # Нормализатор значений из dict/объекта
    def get(u, *keys, default=None):
        for k in keys:
            # dict
            if isinstance(u, dict) and k in u and u[k] is not None:
                return u[k]
            # объект с атрибутом
            if not isinstance(u, dict) and hasattr(u, k):
                v = getattr(u, k)
                if v is not None:
                    return v
        return default

    def norm(u):
        uid = get(u, "user_id", "telegram_id", "id", default="")
        fn = (get(u, "first_name", "firstname", default="") or "").strip()
        ln = (get(u, "last_name", "lastname", default="") or "").strip()
        name = (" ".join([x for x in (fn, ln) if x]) or get(u, "name", default="") or "").strip()
        username = (get(u, "username", "user_name", default="") or "").strip()
        status = (str(get(u, "status", default="")).lower() if get(u, "status") is not None else "")
        is_approved = bool(get(u, "is_approved", "approved", default=False) or status in ("approved","active"))
        role = (str(get(u, "role", default="")).lower() if get(u, "role") is not None else "")
        is_admin = bool(get(u, "is_admin", "admin", default=False) or role in ("admin","owner"))
        return {
            "uid": uid,
            "name": name,
            "username": username,
            "is_approved": is_approved,
            "is_admin": is_admin,
        }

    items = [norm(u) for u in (data or [])]

    pending = [x for x in items if not x["is_approved"]]
    approved = [x for x in items if x["is_approved"]]

    # сортировка: сначала админы, потом по имени/юзернейму/ID
    approved.sort(key=lambda x: (not x["is_admin"], (x["name"] or x["username"] or str(x["uid"])).lower()))

    lines = []

    # Ожидающие авторизации
    if pending:
        lines.append("⏳ Пользователи, ожидающие авторизации:")
        for x in pending:
            uline = f"{x['uid']} — {(x['name'] or '').strip()}"
            if x["username"]:
                uline += f" @{x['username']}"
            lines.append(f"❔ {uline}")
        lines.append("")  # пустая строка-разделитель

    # Зарегистрированные пользователи
    lines.append("👥 Зарегистрированные пользователи:")
    if approved:
        for x in approved:
            icon = "👑" if x["is_admin"] else "👤"
            uline = f"{x['uid']} — {(x['name'] or '').strip()}"
            if x["username"]:
                uline += f" @{x['username']}"
            lines.append(f"{icon} {uline}")
    else:
        lines.append("— пока никого нет")

    # Блок команд
    lines.append("")
    lines.append("Доступные команды:")
    lines.append("• <code>/admin_approve</code> <i>user_id</i> [<i>group_key</i>]")
    lines.append("• /admin_users")
    lines.append("• <code>/admin_removeuser</code> <i>user_id</i>")
    lines.append("• /admin_update_all_users")

    msg = "\n".join(lines)
    await update.message.reply_text(msg, parse_mode="HTML")

@require_admin
async def admin_approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /admin_approve <user_id> [group_key]
    Если указан group_key — сразу назначаем группу.
    """
    if not context.args:
        await update.message.reply_text("❌ Укажите: /admin_approve <user_id> [group_key]")
        return
    try:
        target_user_id = int(context.args[0])
        admin_id = update.effective_user.id

        ok = auth_manager.approve_user(target_user_id, admin_id)
        if not ok:
            await update.message.reply_text("❌ Не удалось одобрить пользователя")
            return

        if len(context.args) >= 2:
            group_key = context.args[1].strip().lower()
            if group_repository.set_user_group(target_user_id, group_key):
                await update.message.reply_text(
                    f"✅ Пользователь {target_user_id} одобрен и назначен в группу <code>{group_key}</code>",
                    parse_mode="HTML"
                )
            else:
                await update.message.reply_text(
                    f"⚠️ Пользователь {target_user_id} одобрен, но группа <code>{group_key}</code> не найдена",
                    parse_mode="HTML"
                )
        else:
            await update.message.reply_text(f"✅ Пользователь {target_user_id} одобрен (группа не назначена)")
    except ValueError:
        await update.message.reply_text("❌ Неверный формат ID пользователя")


@require_admin
async def admin_pending(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pending_users = auth_manager.get_pending_users()
    if not pending_users:
        await update.message.reply_text("📋 Нет пользователей, ожидающих одобрения.")
        return

    message = "⏳ <b>Пользователи, ожидающие одобрения:</b>\n\n"
    for user in pending_users:
        full_name = f"{user.get('first_name','')} {user.get('last_name','')}".strip()
        username = f"@{user['username']}" if user.get('username') else "Без username"
        message += (
            f"🆔 <code>{user['user_id']}</code>\n"
            + (f"👤 {full_name}\n" if full_name else "")
            + f"🔗 {username}\n"
            + f"📅 Зарегистрирован: {user['created_at'].strftime('%d.%m.%Y %H:%M')}\n"
            + ("─" * 20) + "\n"
        )
    message += "\nДля одобрения: /admin_approve <user_id> [group_key]"
    await update.message.reply_text(message, parse_mode='HTML')


@require_admin
async def admin_promote(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❌ Укажите: /admin_promote <user_id>")
        return
    try:
        target_user_id = int(context.args[0])
        admin_id = update.effective_user.id
        if auth_manager.promote_to_admin(target_user_id, admin_id):
            await update.message.reply_text(f"✅ Пользователь {target_user_id} стал администратором")
        else:
            await update.message.reply_text("❌ Не удалось назначить администратора")
    except ValueError:
        await update.message.reply_text("❌ Неверный формат ID пользователя")


@require_admin
async def admin_demote(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❌ Укажите: /admin_demote <user_id>")
        return
    try:
        target_user_id = int(context.args[0])
        admin_id = update.effective_user.id
        if auth_manager.demote_from_admin(target_user_id, admin_id):
            await update.message.reply_text(f"✅ Пользователь {target_user_id} больше не администратор")
        else:
            await update.message.reply_text("❌ Не удалось снять права администратора")
    except ValueError:
        await update.message.reply_text("❌ Неверный формат ID пользователя")


@require_admin
async def remove_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❌ Укажите: /admin_removeuser <user_id>")
        return
    try:
        target_user_id = int(context.args[0])
        if user_repo.remove_user(target_user_id):
            await update.message.reply_text(f"🗑 Пользователь {target_user_id} удалён.")
        else:
            await update.message.reply_text("❌ Пользователь не найден или не удалось удалить.")
    except ValueError:
        await update.message.reply_text("❌ Неверный формат ID пользователя")
    except Exception as e:
        logger.error(f"Error removing user: {e}")
        await update.message.reply_text("❌ Ошибка при удалении пользователя")


# ------- Глобальные (старые) графики -------

@require_admin
async def admin_schedules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        from database import schedule_repository
        schedules = schedule_repository.get_all_schedules()
        if not schedules:
            await update.message.reply_text("📋 Глобальных графиков работы не найдено")
            return

        message = "📊 <b>Глобальные графики работы:</b>\n\n"
        for schedule in schedules:
            message += (
                f"• <b>{schedule['name']}</b>\n"
                f"  {schedule['description']}\n"
                f"  ID: <code>{schedule['id']}</code>\n"
                + ("─" * 20) + "\n"
            )
        message += "\n⚙️ Команды: /admin_schedule_create /admin_schedule_edit /admin_schedule_delete"
        await update.message.reply_text(message, parse_mode='HTML')
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка: {str(e)}")


@require_admin
async def admin_schedule_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❌ Укажите: /admin_schedule_delete <id>")
        return
    try:
        schedule_id = int(context.args[0])
        from database import schedule_repository
        if schedule_repository.delete_schedule(schedule_id):
            await update.message.reply_text(f"✅ График ID {schedule_id} удалён")
        else:
            await update.message.reply_text("❌ Не удалось удалить график. Проверьте ID.")
    except ValueError:
        await update.message.reply_text("❌ Неверный формат ID графика")
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка при удалении: {str(e)}")


@require_admin
async def admin_schedule_create(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args or len(context.args) < 2:
        await update.message.reply_text(
            "❌ Укажите: /admin_schedule_create <название> <описание>\n"
            "Пример:\n"
            "/admin_schedule_create суточный \"24 часа работа/48 часов отдыха\""
        )
        return
    try:
        name = context.args[0]
        description = " ".join(context.args[1:])
        from database import schedule_repository
        schedule_id = schedule_repository.create_schedule(name, description)
        await update.message.reply_text(
            f"✅ График создан!\n"
            f"📝 Название: {name}\n"
            f"📋 Описание: {description}\n"
            f"🆔 ID: <code>{schedule_id}</code>",
            parse_mode='HTML'
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка при создании: {str(e)}")


@require_admin
async def admin_schedule_edit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args or len(context.args) < 3:
        await update.message.reply_text(
            "❌ Укажите: /admin_schedule_edit <id> <название> <описание>\n"
            "Пример:\n"
            "/admin_schedule_edit 1 стандартный \"Стандартный график 8/20\""
        )
        return
    try:
        schedule_id = int(context.args[0])
        name = context.args[1]
        description = " ".join(context.args[2:])
        from database import schedule_repository
        if schedule_repository.update_schedule(schedule_id, name, description):
            await update.message.reply_text(
                f"✅ График обновлён!\n"
                f"🆔 ID: {schedule_id}\n"
                f"📝 Новое название: {name}\n"
                f"📋 Новое описание: {description}"
            )
        else:
            await update.message.reply_text("❌ Не удалось обновить график. Проверьте ID.")
    except ValueError:
        await update.message.reply_text("❌ Неверный формат ID графика")
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка при редактировании: {str(e)}")


# ---------------- Группы смен: список/CRUD/назначение ----------------

@require_admin
async def admin_groups(update: Update, context: ContextTypes.DEFAULT_TYPE):
    groups = group_repository.list_groups()
    if not groups:
        await update.message.reply_text("Список групп пуст. Создайте: /admin_groups_seed или /admin_group_create ...")
        return
    lines = ["📚 <b>Группы смен</b>:\n"]
    for g in groups:
        epoch_text = g["epoch"].strftime("%d.%m.%Y") if g["epoch"] else f"BASE+{g['offset_days']}д"
        tz_text = g["tz_name"] or (f"MSK{g['tz_offset_hours']:+d}h")
        lines.append(f"• <code>{g['key']}</code> — {g['name']} (сдвиг {g['offset_days']}д, эпоха: {epoch_text}, TZ: {tz_text})")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


@require_admin
async def admin_group_create(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /admin_group_create <key> <offset_days> <name...>
    Пример: /admin_group_create g1 0 "Смена Барикул"
    """
    if len(context.args) < 3:
        await update.message.reply_text("❌ Укажите: /admin_group_create <key> <offset_days> <name...>")
        return
    key = context.args[0].strip().lower()
    try:
        offset = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ offset_days должен быть числом")
        return
    name = " ".join(context.args[2:])
    gid = group_repository.create_group(key, name, offset_days=offset, epoch=None, tz_offset_hours=0, tz_name=None)
    await update.message.reply_text(f"✅ Группа создана: <code>{key}</code> — {name} (id={gid})", parse_mode="HTML")


@require_admin
async def admin_group_rename(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("❌ Укажите: /admin_group_rename <key> <new_name...>")
        return
    key = context.args[0].strip().lower()
    new_name = " ".join(context.args[1:])
    if group_repository.update_name(key, new_name):
        await update.message.reply_text(f"✅ Имя группы <code>{key}</code> обновлено: {new_name}", parse_mode="HTML")
    else:
        await update.message.reply_text("❌ Группа не найдена")


@require_admin
async def admin_group_set_offset(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("❌ Укажите: /admin_group_set_offset <key> <offset_days>")
        return
    key = context.args[0].strip().lower()
    try:
        offset = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ offset_days должен быть числом")
        return
    if group_repository.set_offset(key, offset):
        await update.message.reply_text(f"✅ Сдвиг группы <code>{key}</code> установлен: {offset} дн.", parse_mode="HTML")
    else:
        await update.message.reply_text("❌ Группа не найдена")


@require_admin
async def admin_group_set_epoch(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("❌ Укажите: /admin_group_set_epoch <key> <DD.MM.YYYY|none>")
        return
    key = context.args[0].strip().lower()
    val = context.args[1].strip().lower()
    epoch = None if val in ("none", "null", "-") else val
    if group_repository.set_epoch(key, epoch):
        msg = f"✅ Эпоха группы <code>{key}</code> " + ("сброшена" if epoch is None else f"установлена: {epoch}")
        await update.message.reply_text(msg, parse_mode="HTML")
    else:
        await update.message.reply_text("❌ Группа не найдена или неверный формат даты")




@require_admin
async def admin_group_set_tz_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /admin_group_set_tz_name <key> <IANA_TZ|none>
    Пример: /admin_group_set_tz_name g2 Asia/Vladivostok
            /admin_group_set_tz_name g2 none
    """
    if len(context.args) < 2:
        await update.message.reply_text("❌ Укажите: /admin_group_set_tz_name <key> <IANA_TZ|none>")
        return
    key = context.args[0].strip().lower()
    val = context.args[1].strip()
    tz_name = None if val.lower() in ("none", "null", "-") else val
    if group_repository.set_tz_name(key, tz_name):
        shown = tz_name or "— (исп. смещение от Москвы)"
        await update.message.reply_text(f"✅ TZ группы <code>{key}</code>: {shown}", parse_mode="HTML")
    else:
        await update.message.reply_text("❌ Группа не найдена")


@require_admin
async def admin_group_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("❌ Укажите: /admin_group_delete <key>")
        return
    key = context.args[0].strip().lower()
    if group_repository.delete_group(key):
        await update.message.reply_text(f"🗑 Группа <code>{key}</code> удалена", parse_mode="HTML")
    else:
        await update.message.reply_text("❌ Группа не найдена")


@require_admin
async def admin_set_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("❌ Укажите: /admin_set_group <user_id> <group_key>")
        return
    try:
        user_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ user_id должен быть числом")
        return
    group_key = context.args[1].strip().lower()
    if group_repository.set_user_group(user_id, group_key):
        await update.message.reply_text(f"✅ Пользователь {user_id} назначен в группу <code>{group_key}</code>", parse_mode="HTML")
    else:
        await update.message.reply_text("❌ Не удалось назначить группу (проверьте <group_key>)")


@require_admin
async def admin_unset_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("❌ Укажите: /admin_unset_group <user_id>")
        return
    try:
        user_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ user_id должен быть числом")
        return
    if group_repository.unset_user_group(user_id):
        await update.message.reply_text(f"✅ У пользователя {user_id} группа снята")
    else:
        await update.message.reply_text("❌ Пользователь не найден")


@require_admin
async def admin_list_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("❌ Укажите: /admin_list_group <group_key>")
        return
    key = context.args[0].strip().lower()
    users = group_repository.list_users_in_group(key)
    if not users:
        await update.message.reply_text("В группе нет пользователей или группа не найдена.")
        return
    lines = [f"👥 <b>Пользователи группы</b> <code>{key}</code>:"]
    for u in users:
        name = f"{u['first_name'] or ''} {u['last_name'] or ''}".strip()
        uname = f"@{u['username']}" if u['username'] else ""
        lines.append(f"• <code>{u['user_id']}</code> {name} {uname}".rstrip())
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


@require_admin
async def admin_time_groups_add_user(update, context):
    """
    /admin_time_groups_add_user <group_key> <user_id> <base_pos>
    Пример: /admin_time_groups_add_user vrn3 486505109 0
    """
    if len(context.args) != 3:
        await update.message.reply_text("⚙️ Использование:\n/admin_time_groups_add_user <group_key> <user_id> <base_pos>")
        return
    group_key, user_id_s, base_pos_s = context.args
    try:
        user_id = int(user_id_s)
        base_pos = int(base_pos_s)
        if base_pos not in (0, 1, 2, 3):
            raise ValueError
    except Exception:
        await update.message.reply_text("❌ base_pos должен быть 0,1,2 или 3")
        return

    ok = group_repository.add_user_to_time_group(group_key, user_id, base_pos)
    if not ok:
        await update.message.reply_text("❌ Группа не найдена или ошибка записи")
        return

    await update.message.reply_text(f"✅ Пользователь {user_id} добавлен в группу <code>{group_key}</code> (base_pos={base_pos})", parse_mode="HTML")


@require_admin
async def admin_time_groups_remove_user(update, context):
    """
    /admin_time_groups_remove_user <group_key> <user_id>
    """
    if len(context.args) != 2:
        await update.message.reply_text("⚙️ Использование:\n/admin_time_groups_remove_user <group_key> <user_id>")
        return
    group_key, user_id_s = context.args
    try:
        user_id = int(user_id_s)
    except Exception:
        await update.message.reply_text("❌ user_id должен быть числом")
        return

    ok = group_repository.remove_user_from_time_group(group_key, user_id)
    if ok:
        await update.message.reply_text(f"✅ Пользователь {user_id} удалён из группы <code>{group_key}</code>", parse_mode="HTML")
    else:
        await update.message.reply_text("ℹ️ Запись не найдена (или уже удалена)")
